import re
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from sqlalchemy.orm import relationship

db = SQLAlchemy()
migrate = Migrate()

class Location(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    lat = db.Column(db.Float)
    lon = db.Column(db.Float)
    city = db.Column(db.String(100))
    state = db.Column(db.String(100))
    weathers = relationship("Weather", back_populates="location")

class Weather(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    date = db.Column(db.DateTime)
    _temperature = db.Column(db.String)
    location_id = db.Column(db.Integer, db.ForeignKey('location.id'))
    location = relationship("Location", back_populates="weathers")

    @property
    def temperature(self):
        return [float(temp) for temp in self._temperature.split(';')]

    @temperature.setter
    def temperature(self, temp_list):
        self._temperature = ';'.join(str(temp) for temp in temp_list)
