from flask_restful import reqparse
from WeatherAPI import validators

# Define the WeatherRequestParser
WeatherRequestParser = reqparse.RequestParser()
WeatherRequestParser.add_argument('id', type=int, required=True, help='ID is required')
WeatherRequestParser.add_argument('date', type=validators.datestring, required=True, help='Date is required')
WeatherRequestParser.add_argument('temperature', type=str, required=True, help='Temperature is required')
WeatherRequestParser.add_argument('location', type=dict, required=True, help='Location is required')
WeatherRequestParser.add_argument('location.lat', type=float, required=True, help='Latitude is required')
WeatherRequestParser.add_argument('location.lon', type=float, required=True, help='Longitude is required')
WeatherRequestParser.add_argument('location.city', type=str, required=True, help='City is required')
WeatherRequestParser.add_argument('location.state', type=str, required=True, help='State is required')

# Define the LocationParser
LocationParser = reqparse.RequestParser()
LocationParser.add_argument('lat', type=float, required=True, help='Latitude is required')
LocationParser.add_argument('lon', type=float, required=True, help='Longitude is required')
LocationParser.add_argument('city', type=str, required=True, help='City is required')
LocationParser.add_argument('state', type=str, required=True, help='State is required')

# Define the WeatherGetParser
WeatherGetParser = reqparse.RequestParser()
WeatherGetParser.add_argument('date', type=validators.datestring, required=True, help='Date is required')
WeatherGetParser.add_argument('lat', type=float, required=True, help='Latitude is required')
WeatherGetParser.add_argument('lon', type=float, required=True, help='Longitude is required')

# Define the WeatherEraseParser
WeatherEraseParser = reqparse.RequestParser()
WeatherEraseParser.add_argument('start', type=validators.datestring, required=True, help='Start date is required')
WeatherEraseParser.add_argument('end', type=validators.datestring, required=True, help='End date is required')
WeatherEraseParser.add_argument('lat', type=float, required=True, help='Latitude is required')
WeatherEraseParser.add_argument('lon', type=float, required=True, help='Longitude is required')

# Define the TemperatureGetParser
TemperatureGetParser = reqparse.RequestParser()
TemperatureGetParser.add_argument('start', type=validators.datestring, required=True, help='Start date is required')
TemperatureGetParser.add_argument('end', type=validators.datestring, required=True, help='End date is required')

# Define the PreferredLocationsParser
PreferredLocationsParser = reqparse.RequestParser()
PreferredLocationsParser.add_argument('date', type=validators.datestring, required=True, help='Date is required')
PreferredLocationsParser.add_argument('lat', type=float, required=True, help='Latitude is required')
PreferredLocationsParser.add_argument('lon', type=float, required=True, help='Longitude is required')
