import datetime as dt

def datestring(value):
    try:
        return dt.datetime.strptime(value, '%Y-%m-%d').date()
    except ValueError:
        raise ValueError('A Date in format, "%Y-%m-%d", is expected.')
