import datetime as dt
import json
import math
from math import radians, sin, cos, sqrt, asin
from flask import Flask, request, Response, Blueprint,jsonify
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import func, and_, desc
from math import radians, sin, cos, sqrt, asin
from WeatherAPI.models import db, Location, Weather

from flask_restful import Resource, Api, fields, marshal

from WeatherAPI.parsers import WeatherRequestParser, WeatherGetParser, LocationParser, WeatherEraseParser, TemperatureGetParser, PreferredLocationsParser
from WeatherAPI.marshallers import resource_fields, temp_fields, no_temp_fields, preferred_location_details

weather_bp = Blueprint('WeatherAPI', __name__)

weatherapi = Api(weather_bp)


def haversine(lat1, lon1, lat2, lon2):
    p = 0.017453292519943295
    r = 6371.0
    lat_diff = (lat2 - lat1) / 2.0
    lon_diff = (lon2 - lon1) / 2.0
    a = sin(p * lat_diff)**2 + sin(p * lon_diff)**2 * cos(p * lat1) * cos(p * lat2)
    d = 2.0 * r * asin(sqrt(a))
    return d

class WeatherListAPI(Resource):

    def get(self):
        print("Inside WeatherListAPI get")
        data = request.json
        print("Get data is, ",data)
        weather_data = Weather.query.order_by(Weather.id).all()
        return jsonify([weather.as_dict() for weather in weather_data])
        

    def post(self):
        data = request.json
        print("Inside WeatherListAPI post")
        print("DATA IS, ",data)
        data = data['request']['body']
        
        existing_weather = Weather.query.filter_by(id=data['id']).first()
        print(existing_weather)
        if existing_weather:
            return jsonify({'message': 'Weather data with the same ID already exists'}), 400

        location = Location.query.filter_by(lat=data['location']['lat'], lon=data['location']['lon']).first()
        if not location:
            location = Location(id=data['id'],lat=data['location']['lat'], lon=data['location']['lon'],
                                city=data['location']['city'], state=data['location']['state'])
            db.session.add(location)
            db.session.commit()

        weather = Weather(id=data['id'], date=data['date'], temperature=str(data['temperature']),
                          location_id=location.id)
        db.session.add(weather)
        db.session.commit()
        return jsonify({'message': 'Weather data added'}), 201


class WeatherEraseAPI(Resource):

    def delete(self):
        print("Inside WeatherEraseAPI")
        start_date = request.args.get('start')
        end_date = request.args.get('end')
        lat = float(request.args.get('lat'))
        lon = float(request.args.get('lon'))

        if start_date and end_date:
            Weather.query.filter(Weather.date.between(start_date, end_date), 
                                 Location.lat == lat, Location.lon == lon).delete()
        else:
            Weather.query.delete()

        db.session.commit()
        return jsonify({'message': 'Weather data erased'}), 200        



    
class TemperatureAPI(Resource):

    def get(self):
        print("Inside TemperatureAPI")
        args = TemperatureGetParser.parse_args()
        start_date = args['start']
        end_date = args['end']

        # Fetch temperature data for the given date range
        weather_data = Weather.query.filter(Weather.date.between(start_date, end_date)).all()

        if not weather_data:
            return jsonify([{'lat': loc.lat, 'lon': loc.lon, 'city': loc.city, 'state': loc.state, 'message': 'There is no weather data in the given date range'} for loc in Location.query.all()])

        results = []
        for location in Location.query.all():
            temps = [weather.temperature for weather in weather_data if weather.location_id == location.id]
            if temps:
                results.append({
                    'lat': location.lat,
                    'lon': location.lon,
                    'city': location.city,
                    'state': location.state,
                    'lowest': min(temps),
                    'highest': max(temps)
                })
            else:
                results.append({
                    'lat': location.lat,
                    'lon': location.lon,
                    'city': location.city,
                    'state': location.state,
                    'message': 'There is no weather data in the given date range'
                })

        return jsonify(sorted(results, key=lambda x: (x['city'], x['state']))), 200       

    
class PreferredLocationsAPI(Resource):
    
    def get(self):
        print("Inside PreferredLocationsAPI")
        date = request.args.get('date')
        lat = float(request.args.get('lat'))
        lon = float(request.args.get('lon'))

        preferred_locations = []
        for location in Location.query.filter(Location.state != request.json['location']['state']).all():
            weather = Weather.query.filter(and_(Weather.location_id == location.id,
                                                 Weather.date == date)).first()
            if not weather:
                continue

            next_72_hours_weather = Weather.query.filter(and_(Weather.location_id == location.id,
                                                               Weather.date != date)).limit(72).all()
            if not next_72_hours_weather:
                continue

            if all(abs(float(tg) - float(tc)) <= 20 for tg, tc in zip(weather.temperature.split(';'),
                                                                      [t.temperature for t in next_72_hours_weather])):
                distance = haversine(lat, lon, location.lat, location.lon)
                median_temp = sorted([float(t.temperature) for t in next_72_hours_weather])[36]
                preferred_locations.append({
                    'lat': location.lat,
                    'lon': location.lon,
                    'city': location.city,
                    'state': location.state,
                    'distance': round(distance),
                    'median_temperature': round(median_temp, 1)
                })

        preferred_locations = sorted(preferred_locations, key=lambda x: (x['distance'], x['median_temperature'],
                                                                          x['city'], x['state']))
        return jsonify(preferred_locations), 200        
        
weatherapi.add_resource(WeatherListAPI, '/weather')
weatherapi.add_resource(WeatherEraseAPI, '/erase')
weatherapi.add_resource(TemperatureAPI, '/weather/temperature')
weatherapi.add_resource(PreferredLocationsAPI, '/weather/locations')

