from WeatherAPI.models import Location
from flask_restful import fields, marshal

# Define the 'location_details' marshaller
location_details = {
    'id': fields.Integer,
    'name': fields.String,
    'latitude': fields.Float,
    'longitude': fields.Float
}

# Define the 'resource_fields' marshaller
resource_fields = {
    'status': fields.String,
    'message': fields.String,
    'data': fields.Nested(location_details)
}

# Define the 'temp_fields' marshaller
temp_fields = {
    'temperature': fields.Float,
    'unit': fields.String
}

# Define the 'no_temp_fields' marshaller
no_temp_fields = {
    'message': fields.String
}

# Define the 'preferred_location_details' marshaller
preferred_location_details = {
    'id': fields.Integer,
    'name': fields.String,
    'latitude': fields.Float,
    'longitude': fields.Float,
    'temperature': fields.Nested(temp_fields)
}
